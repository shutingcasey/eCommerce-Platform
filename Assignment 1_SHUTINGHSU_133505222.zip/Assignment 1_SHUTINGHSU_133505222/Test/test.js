// var a = 1;
// var b = 3;

console.log("Hello Word !");

// let username

let square = function(n){
    return n * n;
}

console.log(square(2));



